class Movies():
    def __init__(self,title,movie_line,img_url,yt_url):
        self.title=title
        self.movieline=movie_line
        self.poster_image_url=img_url
        self.trailer_youtube_url=yt_url
        
